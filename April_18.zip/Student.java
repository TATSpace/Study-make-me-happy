package April_18;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Student {
    Scanner in = new Scanner(System.in);
    private String name,hobby;
    private double mark;
    private int x;
    private static int total = 0;
    private int id;

    public String getName() {
        return name;
    }

    public String getHobby() {
        return hobby;
    }

    public double getMark() {
        return mark;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public Student(){
        ++total;
        id = total;
    }
    public String getid(){
        DecimalFormat decimalFormat = new DecimalFormat("0");
        return decimalFormat.format(id);
    }
    public String toString(){
        System.out.println("依次输入姓名、爱好、平均绩点：");
        name = in.next();
        hobby = in.next();
        mark = in.nextDouble();
        System.out.println( "姓名为："+ name +"爱好为："+ hobby +"平均绩点为："+ mark);
        System.out.println("是否需要修改，修改姓名请输入1，修改爱好请输入2，修改平均绩点请输入3,不需要修改输入0");
        x = in.nextInt();
        if (x==1){
        name = in.next();
        System.out.println("修改完成");
        return ("姓名为："+ name +"爱好为："+ hobby +"平均绩点为："+ mark);
        }
        if (x==2){
            hobby = in.next();
            System.out.println("修改完成");
            return ("姓名为："+ name +"爱好为："+ hobby +"平均绩点为："+ mark);
        }
        if (x==3){
            mark = in.nextDouble();
            System.out.println("修改完成");
            return ("姓名为："+ name +"爱好为："+ hobby +"平均绩点为："+ mark);
        }
        return ("姓名为："+ name +"爱好为："+ hobby +"平均绩点为："+ mark);

}

    public static void main(String[] args) {
        Student show = new Student();
        System.out.println("ID："+show.getid()+show.toString());
    }
}
