package April_18;

import java.util.Scanner;

public class Complex {
    Scanner in = new Scanner(System.in);
    private double real1,real2;
    private double image1,image2;
    private double plusrealans,plusimageans,subrealans,subimageans;

    public double getImage1() {
        return image1;
    }

    public double getImage2() {
        return image2;
    }

    public double getReal1() {
        return real1;
    }

    public double getReal2() {
        return real2;
    }

    public double getPlusrealans() {
        return plusrealans;
    }

    public double getPlusimageans() {
        return plusimageans;
    }

    public double getSubrealans() {
        return subrealans;
    }

    public double getSubimageans() {
        return subimageans;
    }

    public void setPlusrealans(double plusrealans) {
        this.plusrealans = plusrealans;
    }

    public void setPlusimageans(double plusimageans) {
        this.plusimageans = plusimageans;
    }

    public void setSubimageans(double subimageans) {
        this.subimageans = subimageans;
    }

    public void setSubrealans(double subrealans) {
        this.subrealans = subrealans;
    }

    public void setImage1(double image1) {
        this.image1 = image1;
    }

    public void setImage2(double image2) {
        this.image2 = image2;
    }

    public void setReal1(double real1) {
        this.real1 = real1;
    }

    public void setReal2(double real2) {
        this.real2 = real2;
    }

    public String toString(){
        System.out.println("请依次输入第一个数的实部，虚部；第二个数的实部，虚部：（用空格分隔）");
        real1 = in.nextDouble();
        image1 = in.nextDouble();
        real2 = in.nextDouble();
        image2 = in.nextDouble();
        plusrealans = real1+real2;
        plusimageans = image1+image2;
        subrealans = real1-real2;
        subimageans = image1-image2;
        if (subimageans<0){
        return ("和为"+plusrealans+"+"+plusimageans+"i"+"差为"+(subrealans)+(subimageans)+"i");
    }
        return ("和为"+plusrealans+"+"+plusimageans+"i"+"差为"+(subrealans)+"+"+(subimageans)+"i");
    }
    public static void main(String[] args) {
        Complex ans = new Complex();
        System.out.println(ans.toString());
    }
}

