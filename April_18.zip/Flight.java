package April_18;

import java.math.BigDecimal;
import java.util.Scanner;

public class Flight {
    Scanner in = new Scanner(System.in);
    private String jixing,banci;
    private BigDecimal eding,shiji;
    private BigDecimal zaikelv;

    public String getJixing() {
        return jixing;
    }

    public String getBanci() {
        return banci;
    }

    public BigDecimal getEding() {
        return eding;
    }

    public BigDecimal getShiji() {
        return shiji;
    }

    public void setJixing(String jixing) {
        this.jixing = jixing;
    }

    public void setBanci(String banci) {
        this.banci = banci;
    }

    public void setEding(BigDecimal eding) {
        this.eding = eding;
    }

    public void setShiji(BigDecimal shiji) {
        this.shiji = shiji;
    }
    public String toString(){
        System.out.println("请依次输入机型，班次，额定载客量，实际载客量：");
        jixing = in.next();
        banci = in.next();
        eding = in.nextBigDecimal();
        shiji = in.nextBigDecimal();
        zaikelv = shiji.divide(eding);
        return ("机型为"+jixing+"班次为"+banci+"额定载客量为"+eding+"实际载客量为"+shiji+"载客率为"+zaikelv.multiply(BigDecimal.valueOf(100))+"%");
    }

    public static void main(String[] args) {
        Flight ans = new Flight();
        System.out.println(ans.toString());
    }
}

