package April_18;

import java.util.Scanner;

public class Time {
    Scanner in = new Scanner(System.in);
    private int hour,min,sec;
    private int hour1,min1,sec1;
    private int endhour,endmin,endsec;

    public int getHour() {
        return hour;
    }

    public int getMin() {
        return min;
    }

    public int getSec() {
        return sec;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void setSec(int sec) {
        this.sec = sec;
    }

    public int getHour1() {
        return hour1;
    }

    public int getMin1() {
        return min1;
    }

    public int getSec1() {
        return sec1;
    }

    public void setHour1(int hour1) {
        this.hour1 = hour1;
    }

    public void setMin1(int min1) {
        this.min1 = min1;
    }

    public void setSec1(int sec1) {
        this.sec1 = sec1;
    }
    public String toString(){
        System.out.println("请依次输入时分秒：");
        hour = in.nextInt();
        min = in.nextInt();
        sec = in.nextInt();
        hour1 = in.nextInt();
        min1 = in.nextInt();
        sec1 = in.nextInt();
        endhour = hour + hour1;
        endmin = min + min1;
        endsec = sec + sec1;
        if (endsec>=60 && (endmin+1)>=60){
            return ("时间为"+(endhour+1)+" : "+(endmin+1-60)+" : "+(endsec-60));
        }
        if (endmin>=60){
            return ("时间为"+(endhour+1)+" : "+(endmin-60)+" : "+endsec);
        }
        if (endsec>=60){
            return ("时间为"+endhour+" : "+(endmin+1)+" : "+(endsec-60));
        }
        return ("时间为"+endhour+" : "+endmin+" : "+endsec);

    }

    public static void main(String[] args) {
        Time show = new Time();
        System.out.println(show.toString());
    }
}
