package May_7.mission3;

public class Tri extends Shape{
    protected double l;double h;

    @Override
    public double area() {
        return (l*h)/2;
    }
    public Tri(double l,double h){
        super();
        this.l = l;
        this.h = h;
    }
}
