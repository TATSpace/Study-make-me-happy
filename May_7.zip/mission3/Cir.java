package May_7.mission3;

public class Cir extends Shape{
    protected double r;

    @Override
    public double area() {
        return r*r*Math.PI;
    }
    public Cir(double r){
        super();
        this.r = r;
    }
}
