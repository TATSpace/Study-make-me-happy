package May_7.mission3;

public class Rect extends Shape{
    protected double w;double h;
    @Override
    public double area() {
        return w*h;
    }
    public Rect(double w, double h){
        super();
        this.w = w;
        this.h = h;
    }


}

