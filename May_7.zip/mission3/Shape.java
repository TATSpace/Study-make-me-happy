package May_7.mission3;

public class Shape {
    public double area(){
        return 0;
    }
    public Shape(){
        super();
    }
}
