package May_7.mission3;

public class test {
    public static void main(String[] args) {
        Rect r1 = new Rect(1,9);//长，宽
        System.out.println("矩形面积： "+r1.area());
        Tri t1 = new Tri(3,5);//底，高
        System.out.println("三角形面积： "+t1.area());
        Cir c1 = new Cir(5);//半径
        System.out.println("圆面积： "+c1.area());
    }
}
