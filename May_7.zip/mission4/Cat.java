package May_7.mission4;

public class Cat extends Animal{
    @Override
    public String getAnimalName() {
       return "猫";
    }

    @Override
    public String cry() {
       return "喵喵喵";
    }
}
