package May_7.mission4;

public class Dog extends Animal{
    @Override
    public String getAnimalName() {
        return "狗";
    }

    @Override
    public String cry() {
       return "汪汪汪";
    }
}
