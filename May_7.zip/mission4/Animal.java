package May_7.mission4;

public class Animal {
    public String cry(){
        return null;
    }
    public String getAnimalName(){
        return null;
    }
    public Animal(){
        super();
    }
}
