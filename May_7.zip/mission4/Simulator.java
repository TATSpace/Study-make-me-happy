package May_7.mission4;

public class Simulator {
    public void playSound(Animal animal){
        System.out.println("名字："+animal.getAnimalName()+" 叫声： "+animal.cry());
    }
}
