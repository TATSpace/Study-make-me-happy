package May_7.mission1;

import java.util.Scanner;

public class point {
    protected double x;
    protected double y;
    protected double erwei;
    Scanner in = new Scanner(System.in);
    point(double x,double y){
        this.x = x;
        this.y = y;
        erwei = Math.sqrt((x*x+y*y));
    }

    public static void main(String[] args) {
        point ans = new point(3.0,4.0);
        System.out.println("长度为："+ans.erwei);
    }
}
