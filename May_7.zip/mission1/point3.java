package May_7.mission1;

public class point3 extends point {
    protected double z;
    protected double threewei;
    point3(double x, double y,double z) {
        super(x, y);
        this.z = z;
        threewei = Math.sqrt(erwei*erwei+z*z);
    }

    public static void main(String[] args) {
        point3 ans = new point3(2.0,4.0,1.0);
        System.out.println(ans.threewei);
    }
}
