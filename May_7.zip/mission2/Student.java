package May_7.mission2;

public class Student extends Person{
    Student(int stu_num, String stu_name, int stu_class, int stu_mark) {
        super(stu_num, stu_name, stu_class, stu_mark);
    }

    public static void main(String[] args) {
        Student stu = new Student(191204209,"RGW",1902,10086);
        System.out.println(" 学生编号："+stu.stu_num+" 学生姓名："+stu.stu_name+" 学生班级："+stu.stu_class+" 学生成绩："+stu.stu_mark);
    }

}
