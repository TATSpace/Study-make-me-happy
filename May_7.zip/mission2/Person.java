package May_7.mission2;

public class Person {
    protected int stu_num,stu_class,stu_mark,tea_num;
    protected String stu_name,tea_name,tea_level,tea_part;
    public Person (int tea_num,String tea_name,String tea_level,String tea_part){
        this.tea_num = tea_num;
        this.tea_name = tea_name;
        this.tea_level = tea_level;
        this.tea_part = tea_part;
    }

    public Person(int stu_num, String stu_name, int stu_class, int stu_mark) {
        this.stu_num = stu_num;
        this.stu_name = stu_name;
        this.stu_class = stu_class;
        this.stu_mark = stu_mark;
    }
}

