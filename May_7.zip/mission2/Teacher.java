package May_7.mission2;

public class Teacher extends Person{
    Teacher(int tea_num, String tea_name, String tea_level, String tea_part) {
        super(tea_num, tea_name, tea_level, tea_part);
    }

    public static void main(String[] args) {
        Teacher tea = new Teacher(1,"法外狂徒——张三","教授","bilibili");
        System.out.println(" 教师编号："+tea.tea_num+" 教师姓名："+tea.tea_name+" 级别："+tea.tea_level+" 工作部门："+tea.tea_part);
    }
}
